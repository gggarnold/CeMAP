# CeMAP Revision — Installable PWA

An offline-first revision app for CeMAP 1, 2 and 3, built from your two supplied PDFs
(`CeMAP_1__Delegate_2026.pdf`, `CeMAP_2-3__Delegate_2026.pdf`). React + TypeScript + Vite,
IndexedDB (via Dexie) for all local progress, and a service worker for offline use and
"Add to Home Screen" installation on iPhone.

**Read [CONTENT_COVERAGE.md](./CONTENT_COVERAGE.md) before relying on this for exam prep.**
This first build has a small, fully-verified core of content plus the complete app
architecture — it is **not** yet full coverage of all three qualifications. See that file
for exactly what's in and what's still to be added.

## What's real vs what's a working shell

- **The app itself is fully functional** — every screen, button and feature described below
  works end-to-end (not mockups): lessons, spaced-repetition flashcards, quizzes, a timed
  mock exam, calculators, glossary, planner, analytics, settings, and full offline support.
- **The content is partial and clearly labelled.** 5 topics across the three qualifications
  have complete lessons/flashcards/questions, all fact-checked against your PDFs. The
  remaining ~30 topics show an honest "not yet authored" card with the exact page range in
  your PDF, rather than fake or invented content.
- Two original mock papers are included in full, with every answer verified against your
  PDFs' own answer keys: CeMAP 1 Unit 1 Specimen Paper A (40 Qs), and CeMAP 3 Case Study 1
  (10 Qs).

## Requirements

- Node.js 18+ and npm.

## Setup

```bash
npm install
npm run dev       # local development server, http://localhost:5173
npm run build     # production build into dist/
npm run preview   # preview the production build locally
```

> **Note on this build:** this project was written in a sandboxed environment without
> internet access, so `npm install` / `npm run build` could not be run or verified here.
> Everything has been hand-checked for correct syntax and imports, but please run
> `npm install && npm run build` yourself and report anything that doesn't compile —
> it's straightforward to fix.

## Deploying (free hosting)

### Vercel / Netlify / Cloudflare Pages (recommended — simplest)
1. Push this project to a GitHub repository.
2. Import the repo in Vercel, Netlify, or Cloudflare Pages.
3. Build command: `npm run build`. Output directory: `dist`.
4. Deploy — no other configuration needed. `vite.config.ts`'s `base: '/'` is correct for a
   custom/root domain deployment on any of these three.

### GitHub Pages
1. In `vite.config.ts`, change `base: '/'` to `base: '/your-repo-name/'`.
2. `npm run build`, then deploy the `dist/` folder to the `gh-pages` branch (e.g. using the
   `gh-pages` npm package, or a GitHub Action).
3. Because this is a single-page app, ensure GitHub Pages serves `index.html` for unknown
   routes (a `404.html` that redirects to `index.html`, or use hash routing) — GitHub Pages
   doesn't support server-side rewrites the way Vercel/Netlify do.

## Installing on iPhone

1. Open the deployed URL in **Safari** (not Chrome — iOS PWA installation requires Safari).
2. Tap the **Share** icon (square with an arrow) in the toolbar.
3. Tap **Add to Home Screen**.
4. Confirm the name and tap **Add**.
5. The app now opens full-screen from your Home Screen, works offline after first load, and
   keeps all your progress locally on your device.

## Architecture

- `src/data/` — all study content (lessons, flashcards, questions, mock exams, glossary,
  calculations, curriculum map, exam configs). Pure data, no UI logic — this is what you'd
  extend to add more topics.
- `src/db/` — Dexie (IndexedDB) schema for all **user progress** (lesson completion,
  flashcard SM-2 state, quiz attempts, bookmarks, flags, mock attempts, study sessions,
  planner tasks/settings, app settings). Content and progress are kept strictly separate.
- `src/lib/` — spaced repetition (SM-2), answer-shuffling that preserves the correct answer,
  progress/analytics aggregation, and JSON export/import.
- `src/pages/` — one file per screen.
- `src/components/` — shared UI (bottom nav, top bar, progress ring).

## Adding more content

Every authored topic follows the same pattern — see `src/data/lessons.ts`,
`src/data/questions.ts` and `src/data/flashcards.ts` for the 5 existing examples. To add a
new topic:

1. Change its `status` from `'pending'` to `'complete'` in `src/data/curriculum.ts`.
2. Add a `Lesson` object to `src/data/lessons.ts` with the same `module`/`unitKey`/`topicKey`.
3. Add `Question` objects to `src/data/questions.ts` for that topic.
4. Add `Flashcard` objects to `src/data/flashcards.ts` for that topic.

No other file needs to change — the UI reads everything from these data files.

## Testing checklist

Manual checks to run yourself once `npm run build` succeeds:

- [ ] `npm run dev` starts without errors; all 6 bottom-nav tabs load
- [ ] A lesson can be read, its knowledge check answered, and marked complete
- [ ] A "not yet authored" topic shows the honest placeholder, not a broken link
- [ ] Flashcard study session: reveal, rate (Again/Hard/Good/Easy), due count changes
- [ ] Quick 10 / topic / bookmarked / incorrect / weak-area quizzes all run and record attempts
      in Analytics
- [ ] The Specimen Paper A mock exam: timer counts down, flag/unflag works, submit
      confirmation appears, results show a topic breakdown and full review
- [ ] Calculations: all 4 interactive calculators return sensible numbers for the worked
      example inputs
- [ ] Glossary search and A-Z grouping work
- [ ] Planner: generating a plan creates tasks; marking one done/skipped updates the list
- [ ] Settings: theme and text size change immediately; export progress JSON downloads;
      importing it back restores state; reset progress requires confirmation
- [ ] Close the browser tab and reopen — all progress persists (IndexedDB)
- [ ] Turn off Wi-Fi/data after first load — app still opens and works (service worker cache)
- [ ] `npm run build && npm run preview` — production build works identically to dev
- [ ] Add to Home Screen on an actual iPhone in Safari — icon, splash, safe-area insets all
      look correct in both portrait and landscape

## Known items requiring your confirmation

- Exam pass marks/timings were taken directly from your PDFs' own "Format of the Exam"
  sections and are believed accurate, but double-check against libf.ac.uk in case the
  format has changed since your course materials were printed.
- All tax/allowance figures are deliberately kept at the level of principle, not fixed
  numbers, since your own PDF states these change every Budget — verify current-year
  figures independently before your exam sitting.
