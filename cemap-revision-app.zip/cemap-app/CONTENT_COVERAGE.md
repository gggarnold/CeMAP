# Content Coverage Report

Generated for this build. This is the honest, complete picture of what has been extracted
from your two PDFs and turned into app content, vs what still needs doing.

**Status: CeMAP 1 Unit 1 (Regulation, Legislation & Key Parties) is now 100% complete —
all 12 topics fully authored and verified.** Next up per your instructions: CeMAP 1 Unit 2,
then CeMAP 2, then CeMAP 3 — topic lessons first, remaining specimen papers/case studies after.

## Source files analysed
- `CeMAP_1__Delegate_2026.pdf` — 269 pages, covers CeMAP 1 (Units 1 & 2, FRE1/FRE2)
- `CeMAP_2-3__Delegate_2026.pdf` — 264 pages, covers CeMAP 2 (Units 1 & 2, MRT1/MRT2) and
  CeMAP 3 (Protection Issues, case-study based)

Both were fully read and indexed (table of contents, all topic headings, all topic-test
question banks, all specimen papers/case studies, and both PDFs' own answer-key sections).
For CeMAP 1, the complete Unit 1 & Unit 2 topic-test answer keys were extracted in one pass
directly from the PDF's own "ANSWERS" section (p.260+), so every question below has been
checked against the source, not estimated.

## Fully authored (lessons + flashcards + question bank), verified against source

### CeMAP 1, Unit 1 — Regulation, Legislation & Key Parties (FRE1) — 100% complete
| Topic | Source pages | Questions |
|---|---|---|
| Topic 1 — The Role and Structure of Financial Markets | p.7-20 | 18 |
| Topic 2 Part 1 — The Role of Government | p.21-29 | 12 |
| Topic 2 Part 2 — Taxation | p.30-40 | 16 |
| Topic 3 — State Benefits | p.41-49 | 16 |
| Topic 4 Part 1 — Protection | p.50-63 | 16 |
| Topic 4 Part 2 — Savings & Investments | p.64-74 | 17 |
| Topic 4 Part 3 — Retirement & Borrowing | p.75-86 | 16 |
| Topic 5 — Legal Principles | p.87-100 | 20 |
| Topic 6 — Wills, Intestacy & Trusts | p.101-114 | 15 |
| Topic 7 — Development of UK Regulation | p.115-126 | 12 |
| Topic 8 Part 1 — PRA & FCA Approach to Regulation | p.127-136 | 15 |
| Topic 8 Part 2 — PRA & FCA Approach to Regulation | p.137-143 | 18 |

**191 verified questions across all 12 Unit 1 topics**, every answer cross-checked against
the PDF's own "ANSWERS" section. Several calculation-style questions (real interest rate,
IHT taper relief, intestacy statutory legacy splits, mortgage capital repayment) were also
independently re-derived by hand to confirm the arithmetic matched the stated correct answer.

### Other qualifications (unchanged from previous batch)
| Qualification | Unit | Topic | Source pages |
|---|---|---|---|
| CeMAP 2 | Unit 2 (MRT2) | Topic 1 — Mortgage Repayment Methods | p.135-141 |
| CeMAP 3 | — | Protection Needs & Financial Protection Products | p.224-232 |

## Original mock exams / case studies included in full

| ID | Title | Questions | Verified |
|---|---|---|---|
| `c1-u1-specimen-a` | CeMAP 1, Unit 1 — Specimen Paper A | 40 | Yes, against PDF answer key |
| `c3-case-study-1` | CeMAP 3 — Case Study 1 (Luke & Jessica) | 10 | Yes, against PDF answer key |

## Exam format configuration (verified, not estimated)

- **CeMAP 1**: 2 units, 40 questions each, 60 minutes each, pass mark 28/40 (70%) per unit.
- **CeMAP 2**: Unit 1 — 50 questions, 60 minutes, pass mark 35/50 (70%). Unit 2 — 40
  questions, 60 minutes, pass mark 28/40 (70%).
- **CeMAP 3**: 6 case studies × 10 questions = 60 questions, 120 minutes, pass mark 42/60
  (70%).

## Not yet authored (exists in your PDFs, page ranges below)

### CeMAP 1, Unit 2 (Advisers, Clients and Ethics) — entirely pending (next up)
- Topic 1 — Advice Process & Adviser Skills (p.144-157)
- Topic 2 Part 1 — Consumer Rights & Ethical Outcomes (p.158-165)
- Topic 2 Part 2 — Money Laundering, Data & Complaints (p.166-178)
- Topic 3 — Regulatory Advice Framework (p.179-191)
- Topic 4 — Ethical Principles (p.192-202)
- Plus: Unit 1 Specimen Papers B & C, Unit 2 Specimen Papers A-C (all present in the PDF
  with answer keys, not yet transcribed — per your instruction, mock papers are being added
  after all topic lessons for a qualification are complete)

### CeMAP 2, Unit 1 (Mortgage Law, Practice & Application) — entirely pending
- All 10 topics (p.7-134) — property/mortgage markets, mortgage regulation, mortgage &
  property law, buying a property, the legal side of purchase, the adviser's role, credit
  status & suitability, valuations & surveys, other lending factors.

### CeMAP 2, Unit 2 (Mortgage Products and Post Completion)
- Topic 2 — Repayment Vehicles for Interest-Only Mortgages (p.145-158)
- Topic 3 — Interest Rate Options (p.159-168)
- Topics 4&5 — Mortgage Products and Schemes (p.169-182)
- Topic 6 — Raising Additional Funds for Property (p.183-196)
- Topic 7 — Transferring Mortgages (p.197-208)
- Topics 8&9 — Arrears and Lenders' Legal Rights and Remedies (p.209-223)

### CeMAP 3 — Protection Issues
- Case Study Practice: Case Studies 2-7 (all present with verified answer keys, not yet
  transcribed — Case Study 1 is done).

## Items flagged for your review (per your instructions, not guessed)

- All tax rates/allowances/bands are deliberately described at the level of principle only.
  Your own PDF states these are Budget-dependent and explicitly says the exam does not test
  fixed figures — the app repeats this instruction rather than inventing current numbers.
- Exam format figures (above) were explicitly stated in your PDFs and required no
  estimation — but LIBF could have updated the format since your materials were printed, so
  verify at libf.ac.uk before relying on them for exam-day expectations.
- No duplicate or near-duplicate questions were found within the authored set.
- No content from unsupplied files is referenced anywhere in the app.

## Recommended next steps

Continuing in the agreed order: CeMAP 1 Unit 2 (5 topics) next, then CeMAP 2 Units 1 & 2 (16
topics), then the rest of CeMAP 3's case studies — each following the exact same
read-source → write-original-text → pull-topic-test → verify-against-answer-key process
used for the 12 topics above.

